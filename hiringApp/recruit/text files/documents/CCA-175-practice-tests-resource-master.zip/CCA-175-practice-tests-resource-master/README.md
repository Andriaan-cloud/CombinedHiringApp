# CCA-175-practice-tests-resource

This repository contains the retail_db dataset files. Download the dataset and upload the same in HDFS.

The structure of the database tables is as below:

<img src="images/Retail_DB.png"><img>
